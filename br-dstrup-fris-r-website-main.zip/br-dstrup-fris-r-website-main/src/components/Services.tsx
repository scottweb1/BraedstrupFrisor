import { motion } from "framer-motion";
import { Scissors, SprayCan } from "lucide-react";

const services = [
  {
    icon: Scissors,
    title: "Herreklip",
    description: "Klassisk klipning med stil og præcision",
    price: "250 kr",
  },
  {
    icon: Scissors,
    title: "Herreklip + Skæg",
    description: "Komplet styling af hår og skæg",
    price: "350 kr",
  },
  {
    icon: SprayCan,
    title: "Skægtrimning",
    description: "Professionel trimning og formning",
    price: "150 kr",
  },
  {
    icon: Scissors,
    title: "Børneklip",
    description: "For de små gentlemen (under 12 år)",
    price: "180 kr",
  },
  {
    icon: Scissors,
    title: "Pensionistklip",
    description: "Herreklip til reduceret pris",
    price: "200 kr",
  },
  {
    icon: SprayCan,
    title: "Vask & Styling",
    description: "Hårvask med professionel styling",
    price: "100 kr",
  },
];

const Services = () => {
  return (
    <section id="services" className="py-24 px-6 bg-secondary">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl font-semibold mb-4 text-foreground">
            Vores <span className="text-gold-gradient">Ydelser</span>
          </h2>
          <p className="font-body text-muted-foreground max-w-xl mx-auto">
            Kvalitet og håndværk i hver klipning
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-card p-8 gold-glow hover:scale-[1.02] transition-transform duration-300"
            >
              <service.icon className="w-8 h-8 text-primary mb-4" />
              <h3 className="font-display text-xl font-medium text-foreground mb-2">
                {service.title}
              </h3>
              <p className="font-body text-sm text-muted-foreground mb-4">
                {service.description}
              </p>
              <p className="font-display text-2xl text-primary font-semibold">
                {service.price}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
