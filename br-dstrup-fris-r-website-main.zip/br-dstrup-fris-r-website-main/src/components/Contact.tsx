import { motion } from "framer-motion";
import { MapPin, Phone } from "lucide-react";

const Contact = () => {
  return (
    <section id="contact" className="py-24 px-6 bg-secondary">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl font-semibold mb-4 text-foreground">
            Find <span className="text-gold-gradient">Os</span>
          </h2>
          <p className="font-body text-muted-foreground max-w-xl mx-auto">
            Besøg os i hjertet af Brædstrup
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-card p-8 md:p-12 gold-glow"
          >
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-display text-xl font-medium text-foreground mb-2">
                    Adresse
                  </h3>
                  <p className="font-body text-muted-foreground">
                    Brædstrup Frisør
                    <br />
                    8740 Brædstrup
                    <br />
                    Danmark
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-display text-xl font-medium text-foreground mb-2">
                    Telefon
                  </h3>
                  <a
                    href="tel:+4575751234"
                    className="font-body text-primary hover:text-gold-light transition-colors"
                  >
                    Ring for tidsbestilling
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-10">
              <a
                href="https://www.google.com/maps/place/Braedstrup+fris%C3%B8r/@55.9733556,9.6119233,436m"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block font-body px-8 py-4 bg-primary text-primary-foreground font-medium tracking-wide hover:bg-gold-light transition-colors duration-300"
              >
                Åbn i Google Maps
              </a>
            </div>
          </motion.div>

          {/* Map Embed */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="gold-glow overflow-hidden min-h-[400px]"
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1090!2d9.6119233!3d55.9733556!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x464caf45c02d4b55%3A0xd6822e0708c497fe!2sBraedstrup%20fris%C3%B8r!5e0!3m2!1sda!2sdk!4v1704067200000!5m2!1sda!2sdk"
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: "400px" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Brædstrup Frisør lokation"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
