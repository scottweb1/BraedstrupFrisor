import { Scissors } from "lucide-react";

const Footer = () => {
  return (
    <footer className="py-12 px-6 bg-background border-t border-border">
      <div className="max-w-6xl mx-auto text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Scissors className="w-6 h-6 text-primary" />
          <span className="font-display text-xl text-foreground">
            Brædstrup Frisør
          </span>
        </div>
        <p className="font-body text-sm text-muted-foreground">
          © {new Date().getFullYear()} Brædstrup Frisør. Alle rettigheder forbeholdes.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
