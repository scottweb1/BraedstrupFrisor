import { motion } from "framer-motion";
import { Clock } from "lucide-react";

const schedule = [
  { day: "Mandag", hours: "09:00 - 17:30" },
  { day: "Tirsdag", hours: "09:00 - 17:30" },
  { day: "Onsdag", hours: "09:00 - 17:30" },
  { day: "Torsdag", hours: "09:00 - 17:30" },
  { day: "Fredag", hours: "09:00 - 17:30" },
  { day: "Lørdag", hours: "09:00 - 13:00" },
  { day: "Søndag", hours: "Lukket" },
];

const Hours = () => {
  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Clock className="w-10 h-10 mx-auto text-primary mb-4" />
          <h2 className="font-display text-4xl md:text-5xl font-semibold mb-4 text-foreground">
            Åbningstider
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-card p-8 md:p-12 gold-glow"
        >
          <div className="space-y-4">
            {schedule.map((item, index) => (
              <motion.div
                key={item.day}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.1 * index }}
                className="flex justify-between items-center py-3 border-b border-border last:border-0"
              >
                <span className="font-body text-foreground font-medium">
                  {item.day}
                </span>
                <span
                  className={`font-body ${
                    item.hours === "Lukket"
                      ? "text-muted-foreground"
                      : "text-primary"
                  }`}
                >
                  {item.hours}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hours;
